# 0.9.1

Pandora's Box mode now allows for card removal and reduces the cost of discovered cards.

# 0.9.0

Added Pandora's Box option to replace your starting deck with Chaos or CHAOS that allows you to randomly generate cards.

All modes now should preserve your starting card.

# 0.8.0

Fixed config options not working properly.

# 0.7.0

Added config to corrupt starting items.

Fixed bug with IncreasedCorruptionOdds

Fixed a bug where the armory wouldn't appear until you click on a different hero/tab.

Fixed a bug with the first seed of the play-session sometimes being the same

# 0.6.0

Fixed bug where no cards were able to be crafted unless OnlyCraftCorrupt was checked

# 0.5.0

Initial Pre-release, enabled singularity support

# 0.4.0

Allowed options to craft corrupted cards

# 0.3.0

Allowed options to randomize starting decks

# 0.2.0

Allowed options to corrupt starting decks

# 0.1.0

Initial testing release. Makes all card rewards corrupted