# 0.6.0

Fixed bug where no cards were able to be crafted unless OnlyCraftCorrupt was checked

# 0.5.0

Initial Pre-release, enabled singularity support

# 0.4.0

Allowed options to craft corrupted cards

# 0.3.0

Allowed options to randomize starting decks

# 0.2.0

Allowed options to corrupt starting decks

# 0.1.0

Initial testing release. Makes all card rewards corrupted